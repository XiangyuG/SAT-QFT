#ifndef SOLVEFROMINPUT_H_
#define SOLVEFROMINPUT_H_






#endif /*SOLVEFROMINPUT_H_*/
