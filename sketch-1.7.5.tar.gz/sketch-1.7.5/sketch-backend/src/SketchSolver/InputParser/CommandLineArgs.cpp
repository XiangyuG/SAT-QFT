#include "timerclass.h"
#include "CommandLineArgs.h"
#include "memory_sampler.h"


CommandLineArgs* PARAMS;
timerclass totalElapsed;
timerclass modelBuilding;
timerclass solution;
statistics::MemorySampler mem;

