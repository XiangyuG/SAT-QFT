#include "FindCheckSolver.h"
#include "timerclass.h"
#include <ctime>
#include <queue>
#include "CommandLineArgs.h"

#ifdef IN
#undef IN
#endif

#ifdef OUT
#undef OUT
#endif

//#define Dtime( out ) out

//#define WITH_RANDOMNESS 1

//extern CommandLineArgs* PARAMS;




////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////


